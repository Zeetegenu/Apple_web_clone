import React from 'react';
import './commonResource/css/styles.css'
import './commonResource/css/bootstrap.css'
import Header from './Header'

function App() {
  return (
    <div className="App">
      <Header />
    </div>
  );
}

export default App;
